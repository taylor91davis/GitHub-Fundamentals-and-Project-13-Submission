Losses occurred on each day: 5 
Player that was playing during each of those times: Mylie Schmidt
The total count of times this player was playing: 13 