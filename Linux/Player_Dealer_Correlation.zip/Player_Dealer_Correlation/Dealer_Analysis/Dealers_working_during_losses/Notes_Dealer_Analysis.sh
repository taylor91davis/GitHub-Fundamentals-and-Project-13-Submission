The primary dealer working at the times where losses occurred: Billy Jones
How many times the dealer worked when major losses occurred: 13
