Time: 08:00:00 
a.m./p.m.: AM 
First name of roulette dealer: Billy
Last name of roulette dealer: Jones