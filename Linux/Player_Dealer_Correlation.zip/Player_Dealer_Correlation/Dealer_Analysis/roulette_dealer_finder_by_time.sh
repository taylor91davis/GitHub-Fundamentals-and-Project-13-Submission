#! /bin/bash
# sh roulette_dealer_finder_by_time.sh Arguement1 Arguement2
# echo $Arguement1= 'date "{+%d-%m}"'
# echo $Arguement2= 'time "{+%h:%m:%s:%p}"'
